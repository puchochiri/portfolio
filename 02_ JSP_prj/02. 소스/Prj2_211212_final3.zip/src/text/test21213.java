package text;

public class test21213 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String path = System.getProperty("./"); System.out.println("현재 작업 경로: " + path);


	}

}
