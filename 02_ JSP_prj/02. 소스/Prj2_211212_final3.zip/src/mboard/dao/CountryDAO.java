package mboard.dao;

import java.util.ArrayList;

import mboard.vo.CountryCovidStatusVo;

public class CountryDAO {

	public static ArrayList<CountryCovidStatusVo> saveCountryListByRecent(String nationNm, String natDefCnt) {
		// TODO Auto-generated method stub
		return null;
	}

}
