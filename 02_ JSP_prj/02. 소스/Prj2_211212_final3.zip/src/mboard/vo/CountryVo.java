package mboard.vo;

public class CountryVo {

}
